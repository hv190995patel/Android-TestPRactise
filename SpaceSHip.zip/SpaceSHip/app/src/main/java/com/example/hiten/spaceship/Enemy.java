package com.example.hiten.spaceship;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;

public class Enemy {
    int xPosition;
    int yPosition;
    int direction;
    Bitmap image;
    private Rect hitbox;


    public Enemy(Context context, int x, int y) {

        this.image = BitmapFactory.decodeResource(context.getResources(), R.drawable.alien_ship2);
        this.xPosition = x;
        this.yPosition = y;
        this.hitbox = new Rect(this.xPosition,this.yPosition,this.xPosition + this.image.getWidth(),this.yPosition + this.image.getHeight());

    }



    public Rect getHitbox() {
        return hitbox;
    }

    public void updateEnemyPosition() {

        this.xPosition = this.xPosition - 15;
        this.hitbox.left = this.xPosition;
        this.hitbox.right = this.xPosition + this.image.getWidth();
        this.updateHitbox();
    }

    private void updateHitbox() {
        // update the position of the hitbox
        this.hitbox.top = this.yPosition;
        this.hitbox.left = this.xPosition;
        this.hitbox.right = this.xPosition + this.image.getWidth();
        this.hitbox.bottom = this.yPosition + this.image.getHeight();
    }


    public void setXPosition(int x) {
        this.xPosition = x;
    }
    public void setYPosition(int y) {
        this.yPosition = y;
    }
    public int getXPosition() {
        return this.xPosition;
    }
    public int getYPosition() {
        return this.yPosition;
    }

    public Bitmap getBitmap() {
        return this.image;
    }

}
