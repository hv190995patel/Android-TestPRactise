package com.example.hiten.spaceship;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;

public class Player {
    int xPosition;
    int yPosition;
    int direction = -1;              // -1 = not moving, 0 = down, 1 = up
    Bitmap playerImage;
    private Rect hitbox;


    public Player(Context context, int x, int y) {
        this.playerImage = BitmapFactory.decodeResource(context.getResources(), R.drawable.player_ship);
        this.xPosition = x;
        this.yPosition = y;

        this.hitbox = new Rect(this.xPosition, this.yPosition, this.xPosition + this.playerImage.getWidth(), this.yPosition + this.playerImage.getHeight());
    }

    public Rect getHitbox() {
        return this.hitbox;
    }



    public void updatePlayerPosition() {
        if (this.direction == 0) {
            // move down
            this.yPosition = this.yPosition - 15;

        }
        else if (this.direction == 1) {
            // move up
            this.yPosition = this.yPosition + 15;
        }


        // update the position of the hitbox
        this.updateHitbox();

    }

    private void updateHitbox() {
        // update the position of the hitbox
        this.hitbox.top = this.yPosition;
        this.hitbox.left = this.xPosition;
        this.hitbox.right = this.xPosition + this.playerImage.getWidth();
        this.hitbox.bottom = this.yPosition + this.playerImage.getHeight();
    }

    public void setXPosition(int x) {
        this.xPosition = x;
        this.updateHitbox();
    }

    public void setYPosition(int y) {

        this.yPosition = y;
        this.updateHitbox();
    }
    public int getXPosition() {
        return this.xPosition;
    }
    public int getYPosition() {
        return this.yPosition;
    }

    /**
     * Sets the direction of the player
     * @param i     0 = down, 1 = up
     */
    public void setDirection(int i) {
        this.direction = i;
    }
    public Bitmap getBitmap() {
        return this.playerImage;
    }

}
