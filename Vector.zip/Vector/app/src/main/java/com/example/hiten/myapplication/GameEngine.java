package com.example.hiten.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GameEngine extends SurfaceView implements Runnable {
    private final String TAG = "VECTOR-MATH";

    // game thread variables
    private Thread gameThread = null;
    private volatile boolean gameIsRunning;

    // drawing variables
    private Canvas canvas;
    private Paint paintbrush;
    private SurfaceHolder holder;

    // Screen resolution varaibles
    private int screenWidth;
    private int screenHeight;

    Sprite bullet;
    Sprite square;
    final int SIZE = 10;

    //CREATE Array of bullets
    List<Sprite> bullets =new ArrayList<Sprite>();

    public GameEngine(Context context, int screenW, int screenH) {
        super(context);

        // intialize the drawing variables
        this.holder = this.getHolder();
        this.paintbrush = new Paint();

        // set screen height and width
        this.screenWidth = screenW;
        this.screenHeight = screenH;

       // Log.d(TAG,"New Size (x,y): (" + bullets.size()) ;

        //Craete Multiple bullets at a time
        for(int i = 0;i<10;i++) {
            Random r = new Random();
            int randomXPos = r.nextInt(this.screenWidth) +1;
            int randomYPos = r.nextInt(this.screenHeight)+1;
            Sprite b = new Sprite(getContext(),randomXPos,randomYPos,SIZE,SIZE);
            bullets.add(b);
        }
//        bullet = new Sprite(getContext(),100,600,SIZE,SIZE);

        //Create 10 * 10 sqaure
        square = new Sprite(getContext(),1000,100,SIZE,SIZE);


    }

    @Override
    public void run() {
        // @TODO: Put game loop in here
        while (gameIsRunning == true) {
            updateGame();
            drawGame();
            controlFPS();
        }
    }




    // Game Loop methods

    boolean squreIsMovingDown = true;
    final int SQUARESPEED =  20;
    public void updateGame() {
        //@TODO: Make the sqaure move
//        if(squreIsMovingDown == true) {
//            square.y = square.y + SQUARESPEED;
//            // if sauare reches bottom swithc the direction
//            if(square.y >=this.screenHeight) {
//                squreIsMovingDown = false;
//            }
//        }
//        else  {
//            square.y = square.y - SQUARESPEED;
//            //IF sware reches top of screen switch the direction
//            if(square.y <=0) {
//                squreIsMovingDown = true;
//            }
//        }

//        Random r = new Random();
//        int randomXPos = r.nextInt(this.screenWidth) + 1;
//        int randomYPos = r.nextInt(this.screenHeight) + 1;
//        square.x = randomXPos;
//        square.y = randomYPos;

        //@TODO MAKE THE BULLET MOVE
        for(int i=0;i<bullets.size();i++ ){
            Sprite bull = bullets.get(i);

            //1. CALCULATE DISTNACE BETWEEN BULLET AND SQAURE
            double a  = (square.x - bull.x);
            double b = (square.y - bull.y);
            double distance = Math.sqrt((a*a) + (b*b));

            //2. Calculate the rate to move
            double xn = (a/distance);
            double yn = (b/distance);

            //3. Move the bullet
            bull.x = bull.x + (int)(xn * 15);
            bull.y = bull.y + (int)(yn * 15);

            Log.d(TAG,"New bullet (x,y): (" + bull.x + "," + bull.y + ")");
        }



    }

    public void drawGame() {
        if (holder.getSurface().isValid()) {

            // initialize the canvas
            canvas = holder.lockCanvas();
            // --------------------------------
            // @TODO: put your drawing code in this section

            // set the game's background color
            canvas.drawColor(Color.argb(255,255,255,255));

            //Draw purple square
            paintbrush.setStrokeWidth(50);
            paintbrush.setStyle(Paint.Style.STROKE);
            paintbrush.setColor(Color.MAGENTA);
            canvas.drawRect(square.x,square.y,square.x+SIZE,square.y+SIZE,paintbrush);


            //Draw black bullet
            for(int i = 0;i<bullets.size();i++) {
                Sprite b = bullets.get(i);
                paintbrush.setColor(Color.BLACK);
                canvas.drawRect(b.x,b.y,b.x + SIZE,b.y + SIZE,paintbrush);
            }


            // --------------------------------
            holder.unlockCanvasAndPost(canvas);
        }

    }

    public void controlFPS() {
        try {
            gameThread.sleep(17);
        }
        catch (InterruptedException e) {

        }
    }


    // Deal with user input


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction() & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_UP:
                square.x = (int) event.getX();
                square.y = (int) event.getY();

                Log.d("PUSH", "PERSON CLICKED AT: (" + event.getX() + "," + event.getY() + ")");
                break;
            case MotionEvent.ACTION_DOWN:

                break;
        }
        return true;
    }

    // Game status - pause & resume
    public void pauseGame() {
        gameIsRunning = false;
        try {
            gameThread.join();
        }
        catch (InterruptedException e) {

        }
    }
    public void  resumeGame() {
        gameIsRunning = true;
        gameThread = new Thread(this);
        gameThread.start();
    }

}
